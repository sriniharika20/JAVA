
import java.util.Scanner;
public class Perisquare {
     public static void main(String[] args) {
        Scanner sc  = new Scanner(System.in);
        int perimeter = 4;
        int  side= sc.nextInt();
        int value = perimeter*side;
        System.out.println("perimeter of a S :"+ value);

        sc.close();
     }
}





